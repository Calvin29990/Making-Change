# Making Change — plateforme de recherche

Prototype Python modifiable visant à explorer comment le risque de change affecte le financement d'infrastructures et comment différents scénarios de couverture peuvent modifier le service de la dette. Projet initial destiné à être discuté et développé dans un dépôt GitHub dédié.

## Démarrer

Python 3.10 ou supérieur. Dans un terminal ouvert dans ce dossier :

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell : .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Ouvrir l'adresse indiquée dans le terminal. Tests sans dépendance supplémentaire : `python -m unittest discover -s tests -v`.

## Nouveau dépôt GitHub

1. Décompresser le ZIP et créer sur GitHub un **dépôt vide** « making-change ».
2. Dans le terminal, se placer dans le dossier décompressé `making-change` puis :

```bash
git init
git add .
git commit -m "Initial Making Change research prototype"
git branch -M main
git remote add origin URL_DE_VOTRE_NOUVEAU_DEPOT
git push -u origin main
```

Remplacer l'URL par celle du dépôt créé. Vérifier la visibilité avant publication : les documents de thèse sont inclus volontairement. Aucun fichier personnel du dépôt d'origine n'est inclus. Les saisies utilisateur ne sont pas stockées dans le dépôt ; un CSV peut être téléchargé manuellement.

## Périmètre et limites

- Profil descriptif (taille, géographie, secteur, devises), dette, exposition contractuelle, scénarios de dépréciation, couverture hypothétique, DSCR et tableau annuel exportable.
- Ce n'est **ni une cotation forward ni un conseil en investissement**. Les taux, coûts, hypothèses et seuils sont saisis par l'utilisateur. Aucune connexion bancaire ou donnée de marché ; aucune disponibilité réelle de couverture vérifiée.
- Stress immédiat et permanent, dette à amortissement annuel constant, intérêts fixes et CFADS constant. Le prototype n'est pas un modèle complet d'infrastructure, de valorisation ou d'exposition économique.
- L'interprétation et les formules sont documentées dans `docs/METHODOLOGIE.md`. Les sources scientifiques et leurs limites figurent dans `docs/SOURCES-ACADEMIQUES.md`. `these/` contient la synthèse, la bibliographie et l'ébauche de thèse d'origine : documents de travail à relire avant diffusion.
- Pour XAF/EUR, un choc est une dévaluation hypothétique et non une fluctuation habituelle tant que la parité fixe reste en vigueur. La vérification du contexte réel n'est pas automatisée.

## Organisation

`app.py` interface Streamlit ; `model.py` calculs purs ; `tests/` tests ; `docs/` hypothèses et littérature ; `these/` documents de travail. Pas de base de données ni de code JavaScript écrit dans le projet (Streamlit utilise ses propres composants web).
